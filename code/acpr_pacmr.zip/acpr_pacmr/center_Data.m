function [X, mean] = center_Data( X )

%% **********************************************
[num d] = size(X);
mean = sum(X, 1) / num;
X = X - repmat(mean, num, 1);

end

