function [ map,MAPperClass ] = calculateMAP( queryset, test_Y ,Dist)

%  Dist = EuDist2(queryset, targetset);
%  Dist = CosineDist(queryset, targetset);
    [~,index] = sort(Dist, 2, 'ascend');
%     returnR = 50;
    returnR = size(index,2);%500;
    classIndex = test_Y(index(:,1:returnR));
    ntest = size(unique(test_Y));
    AP = [];
    
    [num,~] = size( queryset );

    for k = 1:num
        reClassIndex = find(classIndex(k, :) == test_Y(k));
        relength = length(reClassIndex);
        if relength<1
            AP = [AP 0];
            continue
        end
        counts = 1:relength;
        AP =[AP sum(counts./reClassIndex)/relength];
    end
    
    map = mean (AP);
    
%     str = sprintf( 'The MAP of text as query is %f%%\n', map *100 );
%     disp(str);
    
    MAPperClass = [];
    for i = 1:ntest
        APperClass = AP(test_Y == i);
        MAPperClass = [MAPperClass mean(APperClass)];
    end
    
%     save('results/MAPperClass', 'MAPperClass');
end

