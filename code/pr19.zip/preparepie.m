function [Xs,Xt,Ys,Yt] = preparepie(src,tgt)    
% Preprocess data using L2-norm
datapath = './';

    load(fullfile(datapath,[src,'.mat']));
    Xs = fts';
    Xs = Xs*diag(sparse(1./sqrt(sum(Xs.^2))));
    Ys = labels;
    load(fullfile(datapath,[tgt,'.mat'])); 
	Xt = fts';
    Xt = Xt*diag(sparse(1./sqrt(sum(Xt.^2))));
    Yt = labels;
end