function [acc, acc2, A] = ours_sp3(options) 
    Xs = options.xs;
    Ys = options.ys;
    
    Xt = options.xt;
    Yt = options.yt;
    
    if ~isfield(options,'svm')
        options.svm = 1;
    end
    if ~isfield(options,'weight')
        options.weight = 1;
    end
    if ~isfield(options,'init')
        options.init = 0;
    end
    
    addpath('../src/liblinear-2.1/matlab')
   
%     Cls = full(sparse(1:length(Yt),Yt,1));  
    Cls = [];
    if options.init
        Cls = knnclassify(Xt',Xs',Ys,1,'cosine'); 
        Cls = full(sparse(1:size(Xt,2),Cls,1));
        Cls = [Cls, zeros(size(Cls,1),max(Yt)-size(Cls,2))];
    end
    Xt0 = Xt;
    
    Xs = Xs*diag(sparse(1./sqrt(sum(Xs.^2))));
    Xt = Xt*diag(sparse(1./sqrt(sum(Xt.^2))));

    for t = 1:options.T
        fprintf('==============================Iteration [%d]==============================\n',t);
        [~, A] = wJLDA(Xs,Xt0,Ys,Cls,options);old_Cls = Cls;

        Zs = real(A'*Xs);
        Zt = real(A'*Xt);
       
%         Cls = knnclassify(Zt',Zs',Ys,1,'cosine');
        model = fitcknn(Zs', Ys, 'NumNeighbors', 1, 'Distance', 'cosine');
        Cls = predict(model, Zt');
        acc = length(find(Cls==Yt))/length(Yt); fprintf('1NN Acc = %0.4f\n',acc);
        
        K = options.K;

        IDX = knnsearch(Zs', Zt', 'K', K, 'distance', 'cosine');
        Cls = zeros(size(IDX,1),length(unique(Ys)));
        for i = 1:size(Cls,2)
            Cls(:,i) = sum(Ys(IDX) == i,2);
        end
        Cls_c = Cls./K; 
        Cls = Cls_c;
        if ~options.pro
%             temp = knnclassify(Zt',Zs',Ys,1,'cosine');
        model2 = fitcknn(Zs', Ys, 'NumNeighbors', 1, 'Distance', 'cosine');
        temp = predict(model2, Zt');
            Cls = full(sparse(1:size(Xt,2),temp,1));
            Cls = [Cls, zeros(size(Cls,1),length(unique(Ys))-size(Cls,2))];
        end 
        
        if options.sp
            t1 = sort(Cls_c,2,'descend');
            tt = t1(:,1) - 0*t1(:,2);
            [~,b] = sort(tt,'descend');
            easy = b(1:fix(min(options.initrate*options.rate^(t),1.0)*length(Yt)));
            Xt0 = Xt(:,easy);
            Cls = Cls(easy,:);
        else
            Xt0 = Xt;
        end
      
        if size(old_Cls,1) == size(Cls,1) && sum(sum(abs(old_Cls-Cls))) == 0
            break;
        end
    end

    fprintf('**************************\n***************************')
    fprintf('\n\n\n');
    if options.svm
        svmmodel = train(double(Ys), sparse(double(Zs')),'-s 1 -B 1  -q');
        [Cls,~,~] = predict(Yt, sparse(Zt)', svmmodel,'-q');
        acc2 = length(find(Cls==Yt))/length(Yt); fprintf('Final Accuracy: %0.4f\n',acc2);
    else 
        acc2 = 0;
    end
end