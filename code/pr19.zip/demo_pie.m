clear all;
clc;
warning off;

% Set algorithm parameters
options.k = 100;             % subspace base dimension
options.ker = 'primal';     % kernel type, default='linear' options: linear, primal, gauss, poly
% options.ker = 'linear';
options.lambda = 0.01; %0.1   
options.T = 15; % iterations
options.weight = 1;
options.svm = 0;
options.init = 0;

options.K = 5;
options.mc = 1;
options.ls = 1;
options.lt = 1;
options.pro = 1;
options.sp = 1;
% options.initrate = 0.9;
% options.rate = 1.05;
options.initrate = 0.7;
options.rate = 1.1;
options.push = 0.01;


% srcStr = {'PIE05','PIE05','PIE05','PIE05','PIE07','PIE07','PIE07','PIE07','PIE09','PIE09','PIE09','PIE09','PIE27','PIE27','PIE27','PIE27','PIE29','PIE29','PIE29','PIE29'};
% tgtStr = {'PIE07','PIE09','PIE27','PIE29','PIE05','PIE09','PIE27','PIE29','PIE05','PIE07','PIE27','PIE29','PIE05','PIE07','PIE09','PIE29','PIE05','PIE07','PIE09','PIE27'};


srcStr = {'PIE05'};
tgtStr = {'PIE07'};

ffid = fopen('result_pie.txt','at');
fprintf(ffid, '****************************\n %s\n', datestr(now));
fprintf(ffid, 'dim = %d, \t kernel = %s \n******************************\n', options.k,options.ker);
fprintf(ffid, 'weight = %.2f \n******************************\n', options.weight);
fprintf(ffid, 'no inintiation ****************************\n');

results = [];
for iData = 1
    src = char(srcStr{iData});
    tgt = char(tgtStr{iData});
    options.data = strcat(src,'_vs_',tgt);
    % Preprocess data using L2-norm
    [CXs,CXt,CYs,CYt] = preparepie(src,tgt);
    %%
    options.xt = CXt;
    options.yt = CYt;
    options.xs = CXs;
    options.ys = CYs;
    
    [iacc, iacc2, ~]= ours_sp3(options);

    acc = 100*iacc;
    fprintf(ffid,'***************************\n%s : \n mean accuracy: \n',options.data);
    fprintf(ffid,'%.2f\n', acc);
    fprintf(ffid,'\n\n\n$$$$$$$$$$$$$$$$$$$$\n$$$$$$$$$$$$$$$$$$$$$$$$$$\n\n');
end
fclose(ffid);