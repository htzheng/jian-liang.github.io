function [Z,A] = wJLDA(Xs,Xt,Ys,Yt0,options)

% Load algorithm options
addpath(genpath('../liblinear/matlab'));
addpath('../')

if nargin < 5
    error('Algorithm parameters should be set!');
end
if ~isfield(options,'k')
    options.k = 100;
end
if ~isfield(options,'lambda')
    options.lambda = 0.1;
end
if ~isfield(options,'ker')
    options.ker = 'primal';
end
if ~isfield(options,'gamma')
    options.gamma = 1.0;
end
if ~isfield(options,'data')
    options.data = 'default';
end
k = options.k;
lambda = options.lambda;
ker = options.ker;
gamma = options.gamma;
data = options.data;

fprintf('PACET:  data=%s  k=%d  lambda=%f\n',data,k,lambda);

% Set predefined variables
X = [Xs, Xt];
X = X*diag(sparse(1./sqrt(sum(X.^2))));

[m,n] = size(X);
ns = size(Xs,2);
nt = size(Xt,2);
C = max(Ys);

L = zeros(ns+nt);
% build SOURCE-LDA
tp = full(sparse(1:ns,Ys,1));
tp2 = tp*diag(1./(eps+sum(tp)));
tp3 = tp2*tp';
tp4 = (tp3 - eye(ns));
L(1:ns,1:ns) = tp4*tp4';

% Construct MMD matrix
e = [1/ns*ones(ns,1);-1/nt*ones(nt,1)];
M = e*e'*C;
Me = 0;
if ~isempty(Yt0) && size(Yt0,1)==nt
    
    
if isfield(options,'push') && options.push > 0 
    disp('b')
    [~,tt] = sort(Yt0,2);
    tp1 = full(sparse(1:ns,Ys,1));
    tp1 = tp1 * diag(1./(eps+sum(tp1)));
    tp2 = [full(sparse(1:nt,tt(:,1),1)), zeros(nt,max(Ys)-max(tt(:,1)))]';
    tp3 = [full(sparse(1:nt,tt(:,2),1)), zeros(nt,max(Ys)-max(tt(:,2)))]';
    tp22 = [-tp1*tp2;eye(nt)];
    tp33 = [-tp1*tp3;eye(nt)];
    Me = Me + tp22*tp22' - tp33 * tp33';
    Me = Me/(eps + norm(Me,'fro'));    
end
    
    if options.mc
    we = ones(max(Ys),1);
    for c = 1:C
        e = zeros(n,1);
        e(Ys==c) = 1/(eps+length(find(Ys==c)));
        e(ns+1:end) = -Yt0(:,c)/(eps+sum(Yt0(:,c)));
        e(isinf(e)) = 0;e(isnan(e)) = 0;
        M = M + we(c)*e*e';
    end
    end
  
    [vv,tt] = sort(Yt0,2);Yt = Yt0;
    Yt0 = tt(:,end);
    
    % supervised target clustering (Tar - weighted Tar)
    tp = Yt;
    tp2 = tp*inv(tp'*tp + eps*eye(size(tp,2)))*Yt';
    tp3 = [zeros(ns,nt);eye(nt)] - [zeros(ns,nt);eye(nt)]*tp2; 
    
    vv(:) = 1;
    L = options.ls * L + options.lt*diag([zeros(ns,1);vv(:,end)])*(tp3*tp3');
   
end

M = M/norm(M,'fro');
L = L/(eps + norm(L,'fro'));

M = M + options.push*Me +  options.weight*L;

% Construct centering matrix
H = eye(n)-1/(n)*ones(n,n);

if strcmp(ker,'primal')  
    T = X*H*X';
    [A,~] = eigs(X*M*X'+lambda*speye(m), T, k,'sm');  
    Z = real(A(:,1:end)'*X);
else
    K = kernel(ker,X,[],gamma);
    G = zeros(n);
    for iii = 1:1
        [A,~] = eigs(K*M*K'+lambda*speye(n) + 3*1e-1*G, K*H*K',k,'SM');
    end
    Z = real(A'*K);
end


end